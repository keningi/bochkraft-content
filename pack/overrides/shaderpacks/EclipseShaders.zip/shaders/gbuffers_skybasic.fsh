#version 330 compatibility

uniform int renderStage;
uniform float viewHeight;
uniform float viewWidth;

// Cloud uniforms
uniform sampler2D cloudTex; // texture from shaders.properties
uniform float time;         // animation time
uniform float cloudScale;   // size control
uniform float cloudSpeed;   // movement speed

in vec4 glcolor;

#include "lib.glsl"

vec3 screenToView(vec3 screenPos) {
    vec4 ndcPos = vec4(screenPos, 1.0) * 2.0 - 1.0;
    vec4 tmp = gbufferProjectionInverse * ndcPos;
    return tmp.xyz / tmp.w;
}

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

void main() {
    if (renderStage == MC_RENDER_STAGE_STARS) {
        color = glcolor;
    } else {
        // Sky direction
        vec3 pos = screenToView(vec3(gl_FragCoord.xy / vec2(viewWidth, viewHeight), 1.0));
        vec3 dir = normalize(pos);

        // Base sky color
        vec3 skyCol = calcSkyColor(dir);

        // Cloud UV mapping
        vec2 uv = dir.xz / max(dir.y + 0.5, 0.1);
        uv *= cloudScale;
        uv.x += time * cloudSpeed;
        uv = fract(uv);

        // Sample cloud texture
        vec4 cloudSample = texture(cloudTex, uv);

        // Blend clouds with sky using texture alpha
        skyCol = mix(skyCol, cloudSample.rgb, cloudSample.a * 0.8);

        // Apply gamma correction
        color = vec4(pow(skyCol, vec3(1.0 / 2.2)), 1.0);
    }
}
